<!DOCTYPE html>
<html lang="en-US">
<head >
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<script>var et_site_url='https://jarvee.com';var et_post_id='0';function et_core_page_resource_fallback(a,b){"undefined"===typeof b&&(b=a.sheet.cssRules&&0===a.sheet.cssRules.length);b&&(a.onerror=null,a.onload=null,a.href?a.href=et_site_url+"/?et_core_page_resource="+a.id+et_post_id:a.src&&(a.src=et_site_url+"/?et_core_page_resource="+a.id+et_post_id))}
</script><meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v17.7.1 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Jarvee</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Jarvee" />
	<meta property="og:site_name" content="Jarvee" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://jarvee.com/#website","url":"https://jarvee.com/","name":"Jarvee","description":"","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://jarvee.com/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//www.google.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//maxcdn.bootstrapcdn.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Jarvee &raquo; Feed" href="https://jarvee.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Jarvee &raquo; Comments Feed" href="https://jarvee.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/jarvee.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='validate-engine-css-css'  href='https://jarvee.com/wp-content/plugins/wysija-newsletters/css/validationEngine.jquery.css?ver=2.17' type='text/css' media='all' />
<link rel='stylesheet' id='jquery.prettyphoto-css'  href='https://jarvee.com/wp-content/plugins/wp-video-lightbox/css/prettyPhoto.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='video-lightbox-css'  href='https://jarvee.com/wp-content/plugins/wp-video-lightbox/wp-video-lightbox.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='kickstart-pro-css'  href='https://jarvee.com/wp-content/themes/kickstart-pro/style.css?ver=1.3.7' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://jarvee.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://jarvee.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='et_monarch-css-css'  href='https://jarvee.com/wp-content/plugins/monarch/css/style.css?ver=1.4.14' type='text/css' media='all' />
<link rel='stylesheet' id='et-gf-open-sans-css'  href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='google-font-open-sans-css'  href='//fonts.googleapis.com/css?family=Open+Sans%3A300%2C300italic%2C400%2C400italic%2C600%2C600italic%2C700%2C700italic&#038;ver=1.3.7' type='text/css' media='all' />
<script type='text/javascript' src='https://jarvee.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='https://jarvee.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://jarvee.com/wp-content/plugins/wp-video-lightbox/js/jquery.prettyPhoto.js?ver=3.1.6' id='jquery.prettyphoto-js'></script>
<script type='text/javascript' id='video-lightbox-js-extra'>
/* <![CDATA[ */
var vlpp_vars = {"prettyPhoto_rel":"wp-video-lightbox","animation_speed":"fast","slideshow":"5000","autoplay_slideshow":"false","opacity":"0.80","show_title":"true","allow_resize":"true","allow_expand":"true","default_width":"640","default_height":"480","counter_separator_label":"\/","theme":"pp_default","horizontal_padding":"20","hideflash":"false","wmode":"opaque","autoplay":"false","modal":"false","deeplinking":"false","overlay_gallery":"true","overlay_gallery_max":"30","keyboard_shortcuts":"true","ie6_fallback":"true"};
/* ]]> */
</script>
<script type='text/javascript' src='https://jarvee.com/wp-content/plugins/wp-video-lightbox/js/video-lightbox.js?ver=3.1.6' id='video-lightbox-js'></script>
<script type='text/javascript' src='https://jarvee.com/wp-content/themes/kickstart-pro/js/backstretch.js?ver=2.0.4' id='kickstart-backstretch-js'></script>
<script type='text/javascript' id='kickstart-backstretch-set-js-extra'>
/* <![CDATA[ */
var KickstartBackStretchImg = {"src":"\/\/jarvee.com\/wp-content\/uploads\/2017\/07\/serenity2.jpeg"};
/* ]]> */
</script>
<script type='text/javascript' src='https://jarvee.com/wp-content/themes/kickstart-pro/js/backstretch-set.js?ver=1.3.7' id='kickstart-backstretch-set-js'></script>
<link rel="https://api.w.org/" href="https://jarvee.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://jarvee.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://jarvee.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.2" />
<script type="text/javascript">
(function(url){
	if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){ return; }
	var addEvent = function(evt, handler) {
		if (window.addEventListener) {
			document.addEventListener(evt, handler, false);
		} else if (window.attachEvent) {
			document.attachEvent('on' + evt, handler);
		}
	};
	var removeEvent = function(evt, handler) {
		if (window.removeEventListener) {
			document.removeEventListener(evt, handler, false);
		} else if (window.detachEvent) {
			document.detachEvent('on' + evt, handler);
		}
	};
	var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
	var logHuman = function() {
		if (window.wfLogHumanRan) { return; }
		window.wfLogHumanRan = true;
		var wfscr = document.createElement('script');
		wfscr.type = 'text/javascript';
		wfscr.async = true;
		wfscr.src = url + '&r=' + Math.random();
		(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);
		for (var i = 0; i < evts.length; i++) {
			removeEvent(evts[i], logHuman);
		}
	};
	for (var i = 0; i < evts.length; i++) {
		addEvent(evts[i], logHuman);
	}
})('//jarvee.com/?wordfence_lh=1&hid=4C44D424233EAF6C46F68D550D6DED7F');
</script>
<!-- WP Affiliate plugin v6.0.2 - https://www.tipsandtricks-hq.com/wordpress-affiliate-platform-plugin-simple-affiliate-program-for-wordpress-blogsite-1474 -->
<link type="text/css" rel="stylesheet" href="https://jarvee.com/wp-content/plugins/wp-affiliate-platform/affiliate_platform_style.css" />
<script>
            WP_VIDEO_LIGHTBOX_VERSION="1.9.4";
            WP_VID_LIGHTBOX_URL="https://jarvee.com/wp-content/plugins/wp-video-lightbox";
                        function wpvl_paramReplace(name, string, value) {
                // Find the param with regex
                // Grab the first character in the returned string (should be ? or &)
                // Replace our href string with our new value, passing on the name and delimeter

                var re = new RegExp("[\?&]" + name + "=([^&#]*)");
                var matches = re.exec(string);
                var newString;

                if (matches === null) {
                    // if there are no params, append the parameter
                    newString = string + '?' + name + '=' + value;
                } else {
                    var delimeter = matches[0].charAt(0);
                    newString = string.replace(re, delimeter + name + "=" + value);
                }
                return newString;
            }
            </script><style type="text/css" id="et-social-custom-css">
				 
			</style><link rel="preload" href="https://jarvee.com/wp-content/plugins/monarch/core/admin/fonts/modules.ttf" as="font" crossorigin="anonymous"><!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103456114-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103456114-1');
</script>
<link rel="icon" href="https://jarvee.com/wp-content/uploads/2017/07/icon.png" sizes="32x32" />
<link rel="icon" href="https://jarvee.com/wp-content/uploads/2017/07/icon.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://jarvee.com/wp-content/uploads/2017/07/icon.png" />
<meta name="msapplication-TileImage" content="https://jarvee.com/wp-content/uploads/2017/07/icon.png" />
</head>
<body class="error404 custom-background et_monarch header-image full-width-content genesis-breadcrumbs-hidden genesis-footer-widgets-visible"><div class="site-container"><ul class="genesis-skip-link"><li><a href="#genesis-nav-primary" class="screen-reader-shortcut"> Skip to primary navigation</a></li><li><a href="#genesis-content" class="screen-reader-shortcut"> Skip to main content</a></li><li><a href="#genesis-footer-widgets" class="screen-reader-shortcut"> Skip to footer</a></li></ul><header class="site-header"><div class="wrap"><div class="title-area"><p class="site-title"><a href="https://jarvee.com/">Jarvee</a></p></div><div class="widget-area header-widget-area"><nav class="nav-primary" aria-label="Main" id="genesis-nav-primary"><ul id="menu-top-menu" class="menu genesis-nav-menu menu-primary js-superfish"><li id="menu-item-212" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-212"><a href="https://jarvee.com/jarvee-social-media-scheduler-features/"><span >Features</span></a>
<ul class="sub-menu">
	<li id="menu-item-429" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-429"><a href="https://jarvee.com/jarvee-social-media-scheduler-features/"><span >All Features</span></a></li>
	<li id="menu-item-366" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-366"><a href="https://jarvee.com/facebook-marketing-features/"><span >Facebook Features</span></a></li>
	<li id="menu-item-1905" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1905"><a href="https://jarvee.com/instagram-marketing-automation-features/"><span >Instagram Features</span></a></li>
	<li id="menu-item-2829" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2829"><a href="https://jarvee.com/youtube-marketing-features/"><span >Youtube Features</span></a></li>
	<li id="menu-item-365" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-365"><a href="https://jarvee.com/twitter-marketing-features/"><span >Twitter Features</span></a></li>
	<li id="menu-item-363" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-363"><a href="https://jarvee.com/pinterest-marketing-automation-features/"><span >Pinterest Features</span></a></li>
	<li id="menu-item-362" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-362"><a href="https://jarvee.com/linkedin-marketing-automation-features/"><span >LinkedIn Features</span></a></li>
	<li id="menu-item-361" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-361"><a href="https://jarvee.com/tumblr-marketing-automation-features/"><span >Tumblr Features</span></a></li>
</ul>
</li>
<li id="menu-item-1868" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1868"><a href="https://jarvee.com/get-now/"><span >Get Started</span></a></li>
<li id="menu-item-371" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-371"><a href="https://jarvee.com/video-tutorials-jarvee-social-media-automation-software/"><span >Tutorials</span></a>
<ul class="sub-menu">
	<li id="menu-item-3688" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3688"><a href="https://jarvee.com/video-tutorials-jarvee-social-media-automation-software/"><span >Video Tutorials</span></a></li>
	<li id="menu-item-3687" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3687"><a href="https://social-media-courses.jarvee.com/"><span >IG Authority Course *FREE*</span></a></li>
</ul>
</li>
<li id="menu-item-45" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-45"><a href="https://jarvee.com/blog/"><span >Blog</span></a></li>
<li id="menu-item-4082" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4082"><a href="https://jarvee.com/contact/"><span >Contact</span></a></li>
</ul></nav></div></div></header><div class="site-inner"><div class="content-sidebar-wrap"><main class="content" id="genesis-content"><article class="entry"><h1 class="entry-title">Not found, error 404</h1><div class="entry-content"><p>The page you are looking for no longer exists. Perhaps you can return back to the <a href="https://jarvee.com/">homepage</a> and see if you can find what you are looking for. Or, you can try finding it by using the search form below.</p><form class="search-form" method="get" action="https://jarvee.com/" role="search"><label class="search-form-label screen-reader-text" for="searchform-1">Search</label><input class="search-form-input" type="search" name="s" id="searchform-1" placeholder="Search"><input class="search-form-submit" type="submit" value="Go"><meta content="https://jarvee.com/?s={s}"></form></div></article></main></div></div><div class="footer-widgets" id="genesis-footer-widgets"><h2 class="genesis-sidebar-title screen-reader-text">Footer</h2><div class="wrap"><div class="widget-area footer-widgets-1 footer-widget-area"><section id="text-26" class="widget widget_text"><div class="widget-wrap"><h3 class="widgettitle widget-title">About JARVEE</h3>
			<div class="textwidget"><p>With years of experience in social media and business growth, the team behind JARVEE is on a quest to create the best automation tool to bring back control over the continually evolving social media landscape.</p>
</div>
		</div></section>
</div><div class="widget-area footer-widgets-2 footer-widget-area"><section id="nav_menu-3" class="widget widget_nav_menu"><div class="widget-wrap"><h3 class="widgettitle widget-title">Resources</h3>
<div class="menu-footer-1-menu-container"><ul id="menu-footer-1-menu" class="menu"><li id="menu-item-216" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-216"><a href="https://jarvee.com/knowledge-base/">Knowledge Base</a></li>
<li id="menu-item-1869" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1869"><a href="https://jarvee.com/get-now/">Pricing Plans</a></li>
<li id="menu-item-4083" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4083"><a href="https://jarvee.com/contact/">Contact Us</a></li>
<li id="menu-item-9207" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9207"><a href="https://jarvee.com/advertising-opportunities/">Advertising opportunities</a></li>
<li id="menu-item-3685" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3685"><a href="https://social-media-courses.jarvee.com/">Instagram Authority Course</a></li>
</ul></div></div></section>
</div><div class="widget-area footer-widgets-3 footer-widget-area"><section id="nav_menu-4" class="widget widget_nav_menu"><div class="widget-wrap"><h3 class="widgettitle widget-title">Other Links</h3>
<div class="menu-footer-2-menu-container"><ul id="menu-footer-2-menu" class="menu"><li id="menu-item-218" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-218"><a href="https://jarvee.com/terms-of-service/">Terms of Service</a></li>
<li id="menu-item-219" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-219"><a href="https://jarvee.com/privacy-policy/">Privacy Policy</a></li>
<li id="menu-item-1710" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1710"><a href="https://jarvee.com/jarvee-coms-essay-writing-competition/">Essay Writing Competition</a></li>
</ul></div></div></section>
</div><div class="widget-area footer-widgets-4 footer-widget-area"><section id="text-27" class="widget widget_text"><div class="widget-wrap"><h3 class="widgettitle widget-title">Follow us</h3>
			<div class="textwidget"><p><a href="https://twitter.com/adam_jarvee">Twitter</a></p>
</div>
		</div></section>
</div><div class="widget-area footer-widgets-5 footer-widget-area">
		<section id="recent-posts-3" class="widget widget_recent_entries"><div class="widget-wrap">
		<h3 class="widgettitle widget-title">News</h3>

		<ul>
											<li>
					<a href="https://jarvee.com/seo-vs-sem-what-to-choose-for-your-business/">SEO vs SEM &#8211; What To Choose For Your Business</a>
									</li>
											<li>
					<a href="https://jarvee.com/how-to-find-an-affordable-podcast-hosting-platform/">How To Find An Affordable Podcast Hosting Platform</a>
									</li>
											<li>
					<a href="https://jarvee.com/the-important-relativity-between-a-product-strategy-and-a-marketing-strategy/">The Important Relativity Between a Product Strategy and a Marketing Strategy</a>
									</li>
					</ul>

		</div></section>
</div></div></div><footer class="site-footer"><div class="wrap"><p>
<span class="alignleft">Copyright &#x000A9;&nbsp;2021 <a href="http://jarvee.com">JARVEE</a> </span>
<span class="alignright">Follow us on <a href="https://twitter.com/adam_jarvee">Twitter</a></span>
</p></div></footer></div><div class="et_social_pin_images_outer">
					<div class="et_social_pinterest_window">
						<div class="et_social_modal_header"><h3>Pin It on Pinterest</h3><span class="et_social_close"></span></div>
						<div class="et_social_pin_images" data-permalink="" data-title="" data-post_id=""></div>
					</div>
				</div><script type='text/javascript' src='https://jarvee.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.13.7' id='regenerator-runtime-js'></script>
<script type='text/javascript' src='https://jarvee.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/jarvee.com\/wp-json\/","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://jarvee.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.5.3' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://jarvee.com/wp-content/plugins/monarch/js/idle-timer.min.js?ver=1.4.14' id='et_monarch-idle-js'></script>
<script type='text/javascript' id='et_monarch-custom-js-js-extra'>
/* <![CDATA[ */
var monarchSettings = {"ajaxurl":"https:\/\/jarvee.com\/wp-admin\/admin-ajax.php","pageurl":"","stats_nonce":"385a81180f","share_counts":"59fe1a7f36","follow_counts":"595cb3576d","total_counts":"91004844cd","media_single":"1bf4ec010a","media_total":"4f31543a04","generate_all_window_nonce":"6861c191f7","no_img_message":"No images available for sharing on this page"};
/* ]]> */
</script>
<script type='text/javascript' src='https://jarvee.com/wp-content/plugins/monarch/js/custom.js?ver=1.4.14' id='et_monarch-custom-js-js'></script>
<script type='text/javascript' src='https://jarvee.com/wp-includes/js/hoverIntent.min.js?ver=1.10.1' id='hoverIntent-js'></script>
<script type='text/javascript' src='https://jarvee.com/wp-content/themes/genesis/lib/js/menu/superfish.min.js?ver=1.7.10' id='superfish-js'></script>
<script type='text/javascript' src='https://jarvee.com/wp-content/themes/genesis/lib/js/menu/superfish.args.min.js?ver=3.3.5' id='superfish-args-js'></script>
<script type='text/javascript' src='https://jarvee.com/wp-content/themes/genesis/lib/js/skip-links.min.js?ver=3.3.5' id='skip-links-js'></script>
<script type='text/javascript' id='kickstart-responsive-menu-js-extra'>
/* <![CDATA[ */
var KickstartL10n = {"mainMenu":"Menu","subMenu":"Menu"};
/* ]]> */
</script>
<script type='text/javascript' src='https://jarvee.com/wp-content/themes/kickstart-pro/js/responsive-menu.js?ver=1.3.7' id='kickstart-responsive-menu-js'></script>
<script type='text/javascript' src='https://jarvee.com/wp-content/plugins/monarch/core/admin/js/common.js?ver=4.9.3' id='et-core-common-js'></script>
<script type='text/javascript' src='https://www.google.com/recaptcha/api.js?render=6LdxBI4UAAAAAPR2zvJ_UQotZMaRq28AF4uQBDEu&#038;ver=3.0' id='google-recaptcha-js'></script>
<script type='text/javascript' id='wpcf7-recaptcha-js-extra'>
/* <![CDATA[ */
var wpcf7_recaptcha = {"sitekey":"6LdxBI4UAAAAAPR2zvJ_UQotZMaRq28AF4uQBDEu","actions":{"homepage":"homepage","contactform":"contactform"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://jarvee.com/wp-content/plugins/contact-form-7/modules/recaptcha/index.js?ver=5.5.3' id='wpcf7-recaptcha-js'></script>
<script type='text/javascript' src='https://jarvee.com/wp-includes/js/wp-embed.min.js?ver=5.8.2' id='wp-embed-js'></script>
</body></html>

<!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/

Page Caching using disk: enhanced 

Served from: jarvee.com @ 2021-12-24 04:19:07 by W3 Total Cache
-->